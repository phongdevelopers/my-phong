<?php

define('FILE_VERSION_VBULLETIN', '');

?>